package mz.co.vodacom.dao;

import java.sql.Connection;
import java.sql.DriverManager;

import org.sqlite.SQLiteConnection;

public class Conexao {

	static Connection conexao = null;
	
	public static Connection getConexao() {
		if (conexao != null) return conexao;
		try {
			Class.forName("org.sqlite.JDBC");	//Forca o carregamento do driver
			conexao = DriverManager.getConnection("jdbc:sqlite:C:/Users/itelio/workspaceJEE/vodacom/vodacom.sqlite");
			SQLiteConnection sc = (SQLiteConnection) conexao;
			sc.setBusyTimeout(25000);
			System.out.println("LOG: Conectado com sucesso...");
			return conexao;
		} catch (Exception e) {
			System.out.println("LOG: Nao conectado ao servidor: " + e.getMessage());
			return null;
		} catch (UnsatisfiedLinkError e) {
			System.out.println("LOG: Cliente desconectado da bd.\nLOG: MOTIVO: restart do servidor: " + e.getMessage());
			return null;
		}
	}

}
