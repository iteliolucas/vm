package mz.co.vodacom.modelo;

import java.util.List;

public class Bradas {

	private List<Integer> listaBradas;

	public List<Integer> getListaBradas() {
		return listaBradas;
	}

	public void setListaBradas(List<Integer> listaBradas) {
		this.listaBradas = listaBradas;
	}
}
