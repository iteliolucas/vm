package mz.co.vodacom.modelo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class TransferirCredito {
	private int telefone;
	private Double valor;
	private int destinatario;
	
	public int getTelefone() {
		return telefone;
	}
	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}
	public Double getValor() {
		return valor;
	}
	public void setValor(Double valor) {
		this.valor = valor;
	}
	public int getDestinatario() {
		return destinatario;
	}
	public void setDestinatario(int destinatario) {
		this.destinatario = destinatario;
	}	
}
