package mz.co.vodacom.modelo;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Conta {
    private int nrTelefone;
    private String primeiroNome;
    private String nomesMeio;
    private String ultimoNome;
    private String avatar_link;
    private String tipoContrato;
    private String saldo;
    private String bonus;
    private String sms_mms;
    private String megabytes;
    private String notificacaoSaldo;
    private int puk;
    private String tarifa;
    private List<Integer> listaBradas;
    private List<Integer> mensagem;
	
    public Conta() {
		super();
	}

	public int getNrTelefone() {
		return nrTelefone;
	}

	public void setNrTelefone(int nrTelefone) {
		this.nrTelefone = nrTelefone;
	}

	public String getPrimeiroNome() {
		return primeiroNome;
	}

	public void setPrimeiroNome(String primeiroNome) {
		this.primeiroNome = primeiroNome;
	}

	public String getNomesMeio() {
		return nomesMeio;
	}

	public void setNomesMeio(String nomesMeio) {
		this.nomesMeio = nomesMeio;
	}

	public String getUltimoNome() {
		return ultimoNome;
	}

	public void setUltimoNome(String ultimoNome) {
		this.ultimoNome = ultimoNome;
	}

	public String getAvatar_link() {
		return avatar_link;
	}

	public void setAvatar_link(String avatar_link) {
		this.avatar_link = avatar_link;
	}

	public String getTipoContrato() {
		return tipoContrato;
	}

	public void setTipoContrato(String tipoContrato) {
		this.tipoContrato = tipoContrato;
	}

	public String getSaldo() {
		return saldo;
	}

	public void setSaldo(String saldo) {
		this.saldo = saldo;
	}

	public String getBonus() {
		return bonus;
	}

	public void setBonus(String bonus) {
		this.bonus = bonus;
	}

	public String getSms_mms() {
		return sms_mms;
	}

	public void setSms_mms(String sms_mms) {
		this.sms_mms = sms_mms;
	}

	public String getMegabytes() {
		return megabytes;
	}

	public void setMegabytes(String megabytes) {
		this.megabytes = megabytes;
	}

	public String getNotificacaoSaldo() {
		return notificacaoSaldo;
	}

	public void setNotificacaoSaldo(String notificacaoSaldo) {
		this.notificacaoSaldo = notificacaoSaldo;
	}

	public int getPuk() {
		return puk;
	}

	public void setPuk(int puk) {
		this.puk = puk;
	}

	public String getTarifa() {
		return tarifa;
	}

	public void setTarifa(String tarifa) {
		this.tarifa = tarifa;
	}

	public List<Integer> getListaBradas() {
		return listaBradas;
	}

	public void setListaBradas(List<Integer> listaBradas) {
		this.listaBradas = listaBradas;
	}

	public List<Integer> getMensagem() {
		return mensagem;
	}

	public void setMensagem(List<Integer> mensagem) {
		this.mensagem = mensagem;
	}
}