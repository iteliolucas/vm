package mz.co.vodacom.dao;

import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import mz.co.vodacom.modelo.Bradas;
import mz.co.vodacom.modelo.Conta;
import mz.co.vodacom.modelo.TransferirCredito;

public class ContaDAO {

	private final String OPERADORA = "84";
	private final int RECARGA = 12;
	private final int NUMERO = 9;
	private static DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

    private final int titulo_erro_ops = 0;
    private final int info_erro_ops = 1;    
    
    private final int titulo_sucesso_recarregar_credito = 100;
    private final int info_sucesso_recarregar_credito_a = 101;
    private final int info_sucesso_recarregar_credito_b = 102;
    private final int titulo_erro_recarregar_credito = 110;
    private final int info_erro_recarregar_credito_usado = 111;
    private final int info_erro_recarregar_credito_invalido = 112;
    
    private final int titulo_sucesso_notificacao_activada = 500;
    private final int info_sucesso_notificacao_activada = 501;
    private final int titulo_erro_notificacao = 510;
    private final int info_erro_notificacao = 511;
    private final int titulo_sucesso_notificacao_desactivada = 550;
    private final int info_sucesso_notificacao_desactivada = 551;
    
    private final int titulo_sucesso_transferir_credito = 700;
    private final int info_sucesso_transferir_credito = 701;
    
    private final int titulo_sucesso_tarifario = 800;
    private final int info_sucesso_tarifario_a = 801;
    private final int info_sucesso_tarifario_b = 802;
    private final int info_sucesso_tarifario_uau = 803;
    private final int info_sucesso_tarifario_seg = 804;
    private final int info_sucesso_tarifario_min = 805;
    private final int info_erro_tarifario = 810;
    private final int info_erro_tarifario_invalido = 811;
    private final int info_erro_tarifario_cliente_invalido = 812;
    
    private final int titulo_sucesso_adicionar_bradas = 900;
    private final int info_sucesso_adicionar_bradas = 901;
    private final int titulo_erro_adicionar_bradas = 910;
    private final int info_erro_adicionar_bradas_exception = 911;
    private final int info_erro_adicionar_bradas_brada_invalido = 912;
    private final int info_erro_adicionar_bradas_cliente_invalido = 913;
    private final int info_erro_adicionar_bradas_listacheia = 914;
    private final int info_erro_adicionar_bradas_brada_ja_existe = 915;
    private final int titulo_sucesso_eliminar_bradas = 950;
    private final int info_sucesso_eliminar_bradas = 951;
    private final int titulo_erro_eliminar_brada= 960;
    private final int info_erro_eliminar_brada_nao_existe = 961;
    private final int info_erro_eliminar_brada_numero_invalido = 962;
    private final int info_erro_eliminar_brada_exception = 963;
    
	public int addConta (Conta conta){
		java.sql.Date dia = new java.sql.Date(Calendar.getInstance().getTime().getTime());
		String conta_Password = null;
		
		synchronized(Conexao.class){
			Connection conexao = Conexao.getConexao();

			// Comando SQL		
			String sql = "INSERT INTO contas (telefone, primeiro_nome, nomes_meio, ultimo_nome, avatar_link, tipo_contrato, password,"
					+ " saldo, bonus, sms_mms, megabytes, ntfSaldo, puk, tarifa)"
					+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

			// Statments
			try {
				PreparedStatement preparadorSQL = conexao.prepareStatement(sql);

				preparadorSQL.setInt(1, conta.getNrTelefone());
				preparadorSQL.setString(2, conta.getPrimeiroNome());
				preparadorSQL.setString(3, conta.getNomesMeio());
				preparadorSQL.setString(4, conta.getUltimoNome());
				preparadorSQL.setString(5, conta.getAvatar_link());
				preparadorSQL.setString(6, conta.getTipoContrato());
				preparadorSQL.setString(7, conta_Password);
				preparadorSQL.setString(8, conta.getSaldo());
				preparadorSQL.setString(9, conta.getBonus());
				preparadorSQL.setString(10, conta.getSms_mms());
				preparadorSQL.setString(11, conta.getMegabytes());
				preparadorSQL.setString(12, conta.getNotificacaoSaldo());
				preparadorSQL.setInt(13, conta.getPuk());
				preparadorSQL.setString(14, conta.getTarifa());				

				// Commit na Base de Dados
				preparadorSQL.execute();
				preparadorSQL.close();

				System.out.println( dateFormat.format(dia)+ " " +conta.getPrimeiroNome()+ "::adicionou::" +conta.getNrTelefone()+ "::1");
				return 1;
			} catch (Exception e) {
				System.out.println( dateFormat.format(dia)+ " " +conta.getPrimeiroNome()+ "::nao-adicionou::" +conta.getNrTelefone()+ "::0::" + e.getMessage() );
				return 0;
			}
		}
	}

	public int deleteConta(int telefone) {
		java.sql.Date dia = new java.sql.Date(Calendar.getInstance().getTime().getTime());

		synchronized(Conexao.class){
			Connection conexao = Conexao.getConexao();

			// Comando SQL
			String sql = "DELETE FROM contas WHERE telefone=?";
			// Statments
			try {
				PreparedStatement preparadorSQL = conexao.prepareStatement(sql);

				preparadorSQL.setLong(1, telefone);

				// Commit na Base de Dados
				preparadorSQL.execute();
				preparadorSQL.close();

				System.out.println( dateFormat.format(dia)+ "::removeu::" +telefone+ "::1");
				return 1;

			} catch (Exception e) {
				System.out.println( dateFormat.format(dia)+ "::nao-removeu::" +telefone+ "::0::" + e.getMessage() );
				return 0;
			}
		}
	}

	public Conta getConta(int telefone, String password, String operacao){
		java.sql.Date dia = new java.sql.Date(Calendar.getInstance().getTime().getTime());
		String conta_Password = null;
		
		Conta conta =  new Conta();

		synchronized(Conexao.class){
			Connection conexao = Conexao.getConexao();

			// Comando SQL
			String sql = "SELECT * FROM contas WHERE telefone = '" +telefone+ "'";

			// Statments
			try {
				PreparedStatement preparadorSQL = conexao.prepareStatement(sql);

				// Commit na Base de Dados
				ResultSet resultado = preparadorSQL.executeQuery();

				//Extrair do Resultset e colocar no objecto banner
				while(resultado.next()){
					conta.setNrTelefone(resultado.getInt("telefone"));						
					conta.setPrimeiroNome(resultado.getString("primeiro_nome"));
					conta.setNomesMeio(resultado.getString("nomes_meio"));
					conta.setUltimoNome(resultado.getString("ultimo_nome"));
					conta.setAvatar_link(resultado.getString("avatar_link"));
					conta.setTipoContrato(resultado.getString("tipo_contrato"));
					conta_Password = resultado.getString("password");
					conta.setSaldo(resultado.getString("saldo"));
					conta.setBonus(resultado.getString("bonus"));
					conta.setSms_mms(resultado.getString("sms_mms"));
					conta.setMegabytes(resultado.getString("megabytes"));
					conta.setNotificacaoSaldo(resultado.getString("ntfSaldo"));
					conta.setPuk(resultado.getInt("puk"));
					conta.setTarifa(resultado.getString("tarifa"));

					List<Integer> listaBradas = new ArrayList<>();
					if (resultado.getString("brada1") != null && resultado.getString("brada1").startsWith(OPERADORA))
						listaBradas.add(resultado.getInt("brada1"));
					if (resultado.getString("brada2") != null && resultado.getString("brada2").startsWith(OPERADORA))
						listaBradas.add(resultado.getInt("brada2"));
					if (resultado.getString("brada3") != null && resultado.getString("brada3").startsWith(OPERADORA))
						listaBradas.add(resultado.getInt("brada3"));
					if (resultado.getString("brada4") != null && resultado.getString("brada4").startsWith(OPERADORA))
						listaBradas.add(resultado.getInt("brada4"));
					if (resultado.getString("brada5")!= null && resultado.getString("brada5").startsWith(OPERADORA))
						listaBradas.add(resultado.getInt("brada5"));

					conta.setListaBradas(listaBradas);
					conta.setMensagem(new ArrayList<Integer>());
				}

				preparadorSQL.close();

				if (operacao.equals("login")){
					// Se o numero de telefone e a password enviados forem iguais ao numero de telefone e a password na BD
					if ( (telefone == conta.getNrTelefone()) && password.equals(conta_Password) ){
						System.out.println( dateFormat.format(dia)+ " " +telefone+ "::conectado::" + "::1");
						return conta;
					}

					System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-conectado::" +"Numero-Ou-Password-Invalidos"+ "::0");
					return null;
				}
				
				return conta;

			} catch (Exception e) {
				System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-conectado::" + " ERRO::" +e.getMessage());
				return null;
			}
		}
	}

	public List<Conta> getContas(){
		java.sql.Date dia = new java.sql.Date(Calendar.getInstance().getTime().getTime());

		List<Conta> listaContas =  new ArrayList<>();

		synchronized(Conexao.class){
			Connection conexao = Conexao.getConexao();

			// Comando SQL
			String sql = "SELECT * FROM contas";

			// Statments
			try {
				PreparedStatement preparadorSQL = conexao.prepareStatement(sql);

				// Commit na Base de Dados
				ResultSet resultado = preparadorSQL.executeQuery();

				//Extrair do Resultset e colocar no objecto banner
				while(resultado.next()){
					Conta conta =  new Conta();

					conta.setNrTelefone(resultado.getInt("telefone"));						
					conta.setPrimeiroNome(resultado.getString("primeiro_nome"));
					conta.setNomesMeio(resultado.getString("nomes_meio"));
					conta.setUltimoNome(resultado.getString("ultimo_nome"));
					conta.setAvatar_link(resultado.getString("avatar_link"));
					conta.setTipoContrato(resultado.getString("tipo_contrato"));
					conta.setSaldo(resultado.getString("saldo"));
					conta.setBonus(resultado.getString("bonus"));
					conta.setSms_mms(resultado.getString("sms_mms"));
					conta.setMegabytes(resultado.getString("megabytes"));
					conta.setNotificacaoSaldo(resultado.getString("ntfSaldo"));
					conta.setPuk(resultado.getInt("puk"));
					conta.setTarifa(resultado.getString("tarifa"));

					List<Integer> listaBradas = new ArrayList<>();
					if (resultado.getString("brada1") != null && resultado.getString("brada1").startsWith(OPERADORA))
						listaBradas.add(resultado.getInt("brada1"));
					if (resultado.getString("brada2") != null && resultado.getString("brada2").startsWith(OPERADORA))
						listaBradas.add(resultado.getInt("brada2"));
					if (resultado.getString("brada3") != null && resultado.getString("brada3").startsWith(OPERADORA))
						listaBradas.add(resultado.getInt("brada3"));
					if (resultado.getString("brada4") != null && resultado.getString("brada4").startsWith(OPERADORA))
						listaBradas.add(resultado.getInt("brada4"));
					if (resultado.getString("brada5")!= null && resultado.getString("brada5").startsWith(OPERADORA))
						listaBradas.add(resultado.getInt("brada5"));

					conta.setListaBradas(listaBradas);

					listaContas.add(conta);
				}
				preparadorSQL.close();

				//System.out.println("Listagem de todas contas executada com sucesso...");

			} catch (Exception e) {
				System.out.println( dateFormat.format(dia)+ " ERRO::" +e.getMessage());
			}
			return listaContas;
		}
	}

	public int updateConta(int telefone, Conta conta){
		java.sql.Date dia = new java.sql.Date(Calendar.getInstance().getTime().getTime());
		String conta_Password = null;
		
		synchronized(Conexao.class){
			Connection conexao = Conexao.getConexao();

			// Comando SQL		
			String sql = "UPDATE contas SET titulo=?, conteudo=? imagem_link=? WHERE telefone=?";

			// Statments
			try {
				PreparedStatement preparadorSQL = conexao.prepareStatement(sql);

				preparadorSQL.setInt(1, conta.getNrTelefone());
				preparadorSQL.setString(2, conta.getPrimeiroNome());
				preparadorSQL.setString(3, conta.getNomesMeio());
				preparadorSQL.setString(4, conta.getUltimoNome());
				preparadorSQL.setString(5, conta.getAvatar_link());
				preparadorSQL.setString(6, conta.getTipoContrato());
				preparadorSQL.setString(7, conta_Password);
				preparadorSQL.setString(8, conta.getSaldo());
				preparadorSQL.setString(9, conta.getBonus());
				preparadorSQL.setString(10, conta.getSms_mms());
				preparadorSQL.setString(11, conta.getMegabytes());
				preparadorSQL.setString(12, conta.getNotificacaoSaldo());
				preparadorSQL.setInt(13, conta.getPuk());
				preparadorSQL.setString(14, conta.getTarifa());				

				// Commit na Base de Dados
				preparadorSQL.executeUpdate();
				preparadorSQL.close();

				System.out.println( dateFormat.format(dia)+ " " +conta.getPrimeiroNome()+ "::actualizou::" +conta.getNrTelefone()+ "::1");
				return 1;
			} catch (Exception e) {
				System.out.println( dateFormat.format(dia)+ " " +conta.getPrimeiroNome()+ "::nao-actualizou::" +conta.getNrTelefone()+ "::0::" + e.getMessage() );
				return 0;
			}
		}
	}

	public Conta updateNotificacaoSaldo(int telefone, String notificacao){

		List<Integer> mensagem = new ArrayList<>();
		java.sql.Date dia = new java.sql.Date(Calendar.getInstance().getTime().getTime());

		// Primeiro verifica se a notificao recebida e valida
		if ( !notificacao.equals("activada") && !notificacao.equals("desactivada") ) {
			System.out.println( dateFormat.format(dia)+ " " +telefone+ "::notificacaoSaldo::nao-" +notificacao+ "::0::" + "Valor da Notificacao Invalido" );
			mensagem.add(titulo_erro_recarregar_credito);
			mensagem.add(info_erro_recarregar_credito_invalido);
			
			return contaComMensagem(telefone, mensagem);
		}

		// Segundo verifica se este numero existe na base de dados
		if (getConta(telefone, "","").getNrTelefone() != telefone){
			System.out.println( dateFormat.format(dia)+ " " +telefone+ "::notificacaoSaldo::nao-"+ notificacao+"::0::" + "Numero Invalido" );
			mensagem.add(titulo_erro_recarregar_credito);
			mensagem.add(info_erro_recarregar_credito_invalido);
			
			return contaComMensagem(telefone, mensagem);
		}

		synchronized(Conexao.class){
			Connection conexao = Conexao.getConexao();

			// Comando SQL		
			String sql = "UPDATE contas SET ntfSaldo=? WHERE telefone=?";

			// Statments
			try {
				PreparedStatement preparadorSQL = conexao.prepareStatement(sql);

				preparadorSQL.setString(1, notificacao);			
				preparadorSQL.setInt(2, telefone);

				// Commit na Base de Dados
				preparadorSQL.executeUpdate();
				preparadorSQL.close();
				
				switch (notificacao) {
					case "activada" :
						mensagem.add(titulo_sucesso_notificacao_activada);
						mensagem.add(info_sucesso_notificacao_activada);					
						break;
	
					case "desactivada" :
						mensagem.add(titulo_sucesso_notificacao_desactivada);
						mensagem.add(info_sucesso_notificacao_desactivada);
						break;
				}

				System.out.println( dateFormat.format(dia)+ " " +telefone+ "::notificacaoSaldo::"+ notificacao+"::1");
				
				return contaComMensagem(telefone, mensagem);

			} catch (Exception e) {
				mensagem.add(titulo_erro_notificacao);
				mensagem.add(info_erro_notificacao);
				
				System.out.println( dateFormat.format(dia)+ " " +telefone+ "::notificacaoSaldo::nao-"+ notificacao+"::0::" + e.getMessage() );
				return contaComMensagem(telefone, mensagem);
			}
		}
	}

	public Conta updateTransferirCredito(int telefone, TransferirCredito transferencia){

		java.sql.Date dia = new java.sql.Date(Calendar.getInstance().getTime().getTime());

		// Primeiro verifica se o valor recebido e valido
		/**		if ( !tarifa.equals("UAU") && !tarifa.equals("por Segundo") && !tarifa.equals("por Minuto")) {
			System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-configurou::Tarifa::" +tarifa+ "::0::" + "Tarifa Invalida" );
			return null;
		}
		 **/
		// Segundo verifica os numero sao validos
		if (getConta(telefone, "", "").getNrTelefone() != telefone){
			System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-transferiu::" + transferencia.getValor() +"MT :: para "+transferencia.getDestinatario()+"::0::" + "Numero do Cliente Invalido" );
			return null;
		}else if( (getConta(telefone, "", "").getNrTelefone()+"").toString().startsWith(OPERADORA) && (getConta(telefone, "", "").getNrTelefone()+"").toString().length() == 9){
			System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-transferiu::" + transferencia.getValor() +"MT :: para "+transferencia.getDestinatario()+"::0::" + "Numero do Destinatario Invalido" );
			return null;
		}

		synchronized(Conexao.class){
			Connection conexao = Conexao.getConexao();

			// Comando SQL		
			String sql = "UPDATE contas SET saldo=? WHERE telefone=?";

			// Statments
			try {
				PreparedStatement preparadorSQL = conexao.prepareStatement(sql);

				preparadorSQL.setString(1, (Double.parseDouble(getConta(telefone, "", "").getSaldo()) - transferencia.getValor()) +"" );			
				preparadorSQL.setInt(2, telefone);

				// Commit na Base de Dados
				preparadorSQL.executeUpdate();
				preparadorSQL.close();

				System.out.println( dateFormat.format(dia)+ " " +telefone+ "::transferiu::"+ transferencia.getValor() +"MT::para "+transferencia.getDestinatario()+"::1");
				return getConta(telefone, "", "");

			} catch (Exception e) {
				System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-transferiu::" + transferencia.getValor() +"MT :: para "+transferencia.getDestinatario()+"::0::" + e.getMessage() );
				return null;
			}
		}
	}

	public Conta updateRecarregarSaldo(int telefone, String codigoRecarga){

		List<Integer> mensagem = new ArrayList<>();
		int valorRecarga = 0;
		
		java.sql.Date dia = new java.sql.Date(Calendar.getInstance().getTime().getTime());

		// Primeiro verifica se o codigo recebido e valido
		if ( codigoRecarga.length() != RECARGA ) {
			System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-recarregou::CodigoDaRecarga::" +codigoRecarga+ "::0::" + "Invalido" );
			mensagem.add(titulo_erro_recarregar_credito);
			mensagem.add(info_erro_recarregar_credito_invalido);
			
			return contaComMensagem(telefone, mensagem);
		}

		// Segundo verifica se o numero e valido
		if (getConta(telefone, "", "").getNrTelefone() != telefone){
			System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-recarregou::CodigoDaRecarga::" +codigoRecarga+ "::0::" + "Numero do Cliente Invalido" );
			mensagem.add(titulo_erro_recarregar_credito);
			mensagem.add(info_erro_recarregar_credito_invalido);
			
			return contaComMensagem(telefone, mensagem);
		}

		/**========================= CODIGO DA FASE DE TESTES	CODIGO DA FASE DE TESTES =========================**/
		if ( codigoRecarga.startsWith("100")) {
			valorRecarga = 100;
			mensagem.add(titulo_sucesso_recarregar_credito);
			mensagem.add(info_sucesso_recarregar_credito_a);
			mensagem.add(valorRecarga);
			mensagem.add(info_sucesso_recarregar_credito_b);
			
		} else if ( codigoRecarga.startsWith("200")) {
			valorRecarga = 200;
			mensagem.add(titulo_sucesso_recarregar_credito);
			mensagem.add(info_sucesso_recarregar_credito_a);
			mensagem.add(valorRecarga);
			mensagem.add(info_sucesso_recarregar_credito_b);
			
		} else if ( codigoRecarga.startsWith("500")) {
			valorRecarga = 500;
			mensagem.add(titulo_sucesso_recarregar_credito);
			mensagem.add(info_sucesso_recarregar_credito_a);
			mensagem.add(valorRecarga);
			mensagem.add(info_sucesso_recarregar_credito_b);			
		}else{
			mensagem.add(titulo_erro_recarregar_credito);
			mensagem.add(info_erro_recarregar_credito_invalido);

			System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-recarregou::CodigoDaRecarga::" +codigoRecarga+ "::0::" + "Codigo de Recarga Invalida" );
			 
			return contaComMensagem(telefone, mensagem);
		}
		/**========================= CODIGO DA FASE DE TESTES	CODIGO DA FASE DE TESTES =========================**/

		synchronized(Conexao.class){
			Connection conexao = Conexao.getConexao();

			// Comando SQL		
			String sql = "UPDATE contas SET saldo=? WHERE telefone=?";

			// Statments
			try {
				PreparedStatement preparadorSQL = conexao.prepareStatement(sql);

				preparadorSQL.setDouble(1, (Double.parseDouble(getConta(telefone, "", "").getSaldo()) + valorRecarga));			
				preparadorSQL.setInt(2, telefone);

				// Commit na Base de Dados
				preparadorSQL.executeUpdate();
				preparadorSQL.close();
				
				System.out.println( dateFormat.format(dia)+ " " +telefone+ "::recarregou::CodigoDaRecarga::" +codigoRecarga+ "::1");
				 
				return contaComMensagem(telefone, mensagem);

			} catch (Exception e) {
				System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-recarregou::CodigoDaRecarga::" +codigoRecarga+ "::0::" + e.getMessage() );
				return contaComMensagem(telefone, mensagem);
			}
		}
	}
	
	public Conta updateTarifario(int telefone, String tarifa){

		List<Integer> mensagem = new ArrayList<>();
		java.sql.Date dia = new java.sql.Date(Calendar.getInstance().getTime().getTime());

		// Primeiro verifica se a tarifa recebida e valida
		if ( !tarifa.equals("UAU") && !tarifa.equals("por Segundo") && !tarifa.equals("por Minuto")) {
			System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-configurou::Tarifa::" +tarifa+ "::0::" + "Tarifa Invalida" );
			mensagem.add(info_erro_tarifario);
			mensagem.add(info_erro_tarifario_invalido);
			
			return contaComMensagem(telefone, mensagem);
		}

		// Segundo verifica se este numero existe na base de dados
		if (getConta(telefone, "", "").getNrTelefone() != telefone){
			System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-configurou::Tarifa::" +tarifa+ "::0::" + "Numero Invalido" );
			mensagem.add(info_erro_tarifario);
			mensagem.add(info_erro_tarifario_cliente_invalido);
			
			return contaComMensagem(telefone, mensagem);
		}

		synchronized(Conexao.class){
			Connection conexao = Conexao.getConexao();

			// Comando SQL		
			String sql = "UPDATE contas SET tarifa=? WHERE telefone=?";

			// Statments
			try {
				PreparedStatement preparadorSQL = conexao.prepareStatement(sql);

				preparadorSQL.setString(1, tarifa);			
				preparadorSQL.setInt(2, telefone);

				// Commit na Base de Dados
				preparadorSQL.executeUpdate();
				preparadorSQL.close();
				
				mensagem.add(titulo_sucesso_tarifario);
				mensagem.add(info_sucesso_tarifario_a);	// alterado de: XXXX
				
				// Tarifa antiga (adicionar a mensagem)
				switch (tarifa) {
					case "UAU" :
						mensagem.add(info_sucesso_tarifario_uau);
						break;
					case "por Segundo" :
						mensagem.add(info_sucesso_tarifario_seg);
						break;
					case "por Minuto" :
						mensagem.add(info_sucesso_tarifario_min);
						break;
				}
				
				mensagem.add(info_sucesso_tarifario_b);	// alterado de: XXXXX para YYYYY
				// Tarifa Nova (adicionar a mensagem)
				switch (tarifa) {
					case "UAU" :
						mensagem.add(info_sucesso_tarifario_uau);
						break;
					case "por Segundo" :
						mensagem.add(info_sucesso_tarifario_seg);
						break;
					case "por Minuto" :
						mensagem.add(info_sucesso_tarifario_min);
						break;
				}
				
				
				System.out.println( dateFormat.format(dia)+ " " +telefone+ "::configurou::Tarifa::" +tarifa+"::1");
				return getConta(telefone, "", "");

			} catch (Exception e) {
				System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-configurou::Tarifa::" +tarifa+ "::0::" + e.getMessage() );
				return null;
			}
		}
	}

	public Conta addBrada (int telefone, String brada){
		List<Integer> mensagem = new ArrayList<>();
		java.sql.Date dia = new java.sql.Date(Calendar.getInstance().getTime().getTime());

		// Primeiro verifica se o numero do brada e valido
		if ( brada.length() != NUMERO ) {
			System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-configurou::Brada::" +brada+ "::0::" + "Numero do Brada Invalido" );
			mensagem.add(titulo_erro_adicionar_bradas);
			mensagem.add(info_erro_adicionar_bradas_brada_invalido);
						
			return contaComMensagem(telefone, mensagem);
		}

		// Segundo verifica se o numero e valido
		if (getConta(telefone, "", "").getNrTelefone() != telefone){
			System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-configurou::Brada::" +brada+ "::0::" + "Numero do Cliente Invalido" );
			mensagem.add(titulo_erro_adicionar_bradas);
			mensagem.add(info_erro_adicionar_bradas_cliente_invalido);
		
			return contaComMensagem(telefone, mensagem);
		}
		
		// Terceiro verifica se o numero do brada ja existe na BD
		if ( procurarBrada(telefone, Integer.parseInt(brada)) != -1) {
			System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-configurou::Brada::" +brada+ "::0::" + "Brada Ja Existe" );
			mensagem.add(titulo_erro_adicionar_bradas);
			mensagem.add(info_erro_adicionar_bradas_brada_ja_existe);
		
			return contaComMensagem(telefone, mensagem);
		}
		
		synchronized(Conexao.class){
			Connection conexao = Conexao.getConexao();
			String sql = null;

			// Comando SQL		
			switch ( procurarPosicaoVaziaParaAdicionarBrada(telefone) ) {
				case 1 : sql = "UPDATE contas SET brada1=? WHERE telefone=?";
				break;
				case 2 : sql = "UPDATE contas SET brada2=? WHERE telefone=?";
				break;
				case 3 : sql = "UPDATE contas SET brada3=? WHERE telefone=?";
				break;
				case 4 : sql = "UPDATE contas SET brada4=? WHERE telefone=?";
				break;
				case 5 : sql = "UPDATE contas SET brada5=? WHERE telefone=?";
				break;
				case -1 : 
					System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-configurou::Brada::" +brada+ "::0::" + "Lista de Bradas esta Cheia" );
					mensagem.add(titulo_erro_adicionar_bradas);
					mensagem.add(info_erro_adicionar_bradas_listacheia);
					
					return contaComMensagem(telefone, mensagem);
			}

			// Statments
			try {
				PreparedStatement preparadorSQL = conexao.prepareStatement(sql);

				preparadorSQL.setInt(1, Integer.parseInt(brada) );
				preparadorSQL.setInt(2, telefone);	

				// Commit na Base de Dados
				preparadorSQL.executeUpdate();
				preparadorSQL.close();

				mensagem.add(titulo_sucesso_adicionar_bradas);
				mensagem.add(info_sucesso_adicionar_bradas);
				
				System.out.println( dateFormat.format(dia)+ " " +telefone+ "::configurou::Brada::" +brada+ "::1");
				
				return contaComMensagem(telefone, mensagem);
			} catch (Exception e) {
				System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-configurou::Brada::" +brada+ "::0::" + e.getMessage() );
				mensagem.add(titulo_erro_adicionar_bradas);
				mensagem.add(info_erro_adicionar_bradas_exception);
				return contaComMensagem(telefone, mensagem);
			}
		}
	}

	public Conta deleteBrada (int telefone, Bradas bradas){
		List<Integer> mensagem = new ArrayList<>();
		int brada = 0;
		java.sql.Date dia = new java.sql.Date(Calendar.getInstance().getTime().getTime());

		// Primeiro verifica se o numero do cliente e valido
		if (getConta(telefone, "", "").getNrTelefone() != telefone){
			System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-eliminou::Brada::" +bradas.getListaBradas()+ "::0::" + "Numero do Cliente Invalido" );
			mensagem.add(titulo_erro_eliminar_brada);
			mensagem.add(info_erro_eliminar_brada_numero_invalido);
			
			return contaComMensagem(telefone, mensagem);
		}
				
		// Segundo verifica se o(s) numero(s) do(s) brada(s) existe(m) na BD
		for (Integer bro : bradas.getListaBradas()) {
			brada = bro;
			if ( procurarBrada(telefone, bro) == -1) {
				System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-eliminou::Brada::" +bro+ "::0::" + "Brada Nao Existe");
				//mensagem.add(titulo_erro_eliminar_brada);
				//mensagem.add(info_erro_eliminar_brada_nao_existe);
				
				//return contaComMensagem(telefone, mensagem);
			}
		}

		synchronized(Conexao.class){
			Connection conexao = Conexao.getConexao();
			String sql;

			// Comando SQL		
			try {
				for (Integer bro : bradas.getListaBradas()) {
					sql = null;
					brada = bro;
					
					switch (procurarBrada(telefone, bro)) {
						case 1 : sql = "UPDATE contas SET brada1=? WHERE telefone=?";
						break;
						case 2 : sql = "UPDATE contas SET brada2=? WHERE telefone=?";
						break;
						case 3 : sql = "UPDATE contas SET brada3=? WHERE telefone=?";
						break;
						case 4 : sql = "UPDATE contas SET brada4=? WHERE telefone=?";
						break;
						case 5 : sql = "UPDATE contas SET brada5=? WHERE telefone=?";
						break;
					}
				
					if (sql != null){
						// Statments
						PreparedStatement preparadorSQL = conexao.prepareStatement(sql);
						preparadorSQL.setInt(1, 0);
						preparadorSQL.setInt(2, telefone);	
			
						// Commit na Base de Dados
						preparadorSQL.executeUpdate();
						preparadorSQL.close();
						
						mensagem.add(titulo_sucesso_eliminar_bradas);
						mensagem.add(info_sucesso_eliminar_bradas);
						
						System.out.println( dateFormat.format(dia)+ " " +telefone+ "::eliminou::Brada::" +bro+ "::1");
					}
				}		
				return contaComMensagem(telefone, mensagem);
			} catch (Exception e) {
				mensagem.add(titulo_erro_eliminar_brada);
				mensagem.add(info_erro_eliminar_brada_exception);
				System.out.println( dateFormat.format(dia)+ " " +telefone+ "::nao-eliminou::Brada::" +brada+ "::0::" + e.getMessage() );
				return contaComMensagem(telefone, mensagem);
			}
		}
	}

	private int procurarPosicaoVaziaParaAdicionarBrada(int telefone){
		
		synchronized(Conexao.class){
			Connection conexao = Conexao.getConexao();
			int posicaoVazia = -1;

			// Comando SQL
			String sql = "SELECT brada1, brada2, brada3, brada4, brada5 FROM contas WHERE telefone = '" +telefone+ "'";

			// Statments
			try {
				PreparedStatement preparadorSQL = conexao.prepareStatement(sql);

				// Commit na Base de Dados
				ResultSet resultado = preparadorSQL.executeQuery();

				while(resultado.next()){
						 if (resultado.getString("brada1") == null || resultado.getString("brada1").isEmpty() || resultado.getString("brada1").length() != NUMERO || !resultado.getString("brada1").startsWith(OPERADORA))
						posicaoVazia = 1;	// Devolve posicao do brada1 para se adicionar um novo brada
					else if (resultado.getString("brada2") == null || resultado.getString("brada2").isEmpty() || resultado.getString("brada2").length() != NUMERO || !resultado.getString("brada2").startsWith(OPERADORA))
						posicaoVazia = 2;	// Devolve posicao do brada2 para se adicionar um novo brada
					else if (resultado.getString("brada3") == null || resultado.getString("brada3").isEmpty() || resultado.getString("brada3").length() != NUMERO || !resultado.getString("brada3").startsWith(OPERADORA))
						posicaoVazia = 3;	// Devolve posicao do brada3 para se adicionar um novo brada
					else if (resultado.getString("brada4") == null || resultado.getString("brada4").isEmpty() || resultado.getString("brada4").length() != NUMERO || !resultado.getString("brada4").startsWith(OPERADORA))
						posicaoVazia = 4;	// Devolve posicao do brada4 para se adicionar um novo brada
					else if ( (resultado.getString("brada5") == null || resultado.getString("brada5").isEmpty()) || resultado.getString("brada5").length() != NUMERO || !resultado.getString("brada5").startsWith(OPERADORA))
						posicaoVazia = 5;	// Devolve posicao do brada5 para se adicionar um novo brada
				}
				preparadorSQL.close();

				return posicaoVazia;

			} catch (Exception e) {
				java.sql.Date dia = new java.sql.Date(Calendar.getInstance().getTime().getTime());
				System.out.println( dateFormat.format(dia)+ " ERRO::" +e.getMessage());
				return posicaoVazia;
			}
		}
	}

	private int procurarBrada(int telefone, int brada){
//		java.sql.Date dia = new java.sql.Date(Calendar.getInstance().getTime().getTime());

		synchronized(Conexao.class){
			Connection conexao = Conexao.getConexao();
			int posicaoBrada = -1;

			// Comando SQL
			String sql = "SELECT brada1, brada2, brada3, brada4, brada5 FROM contas WHERE telefone = '" +telefone+ "'";

			// Statments
			try {
				PreparedStatement preparadorSQL = conexao.prepareStatement(sql);

				// Commit na Base de Dados
				ResultSet resultado = preparadorSQL.executeQuery();

				while(resultado.next()){
						 if (Integer.parseInt( resultado.getString("brada1") ) == brada)
						posicaoBrada = 1;	// Devolve posicao do brada1 para se eliminar
					else if (Integer.parseInt( resultado.getString("brada2") ) == brada)
						posicaoBrada = 2;	// Devolve posicao do brada2 para se adicionar um novo brada
					else if (Integer.parseInt( resultado.getString("brada3") ) == brada)
						posicaoBrada = 3;	// Devolve posicao do brada3 para se adicionar um novo brada
					else if (Integer.parseInt( resultado.getString("brada4") ) == brada)
						posicaoBrada = 4;	// Devolve posicao do brada4 para se adicionar um novo brada
					else if (Integer.parseInt( resultado.getString("brada5") ) == brada)
						posicaoBrada = 5;	// Devolve posicao do brada5 para se adicionar um novo brada
				}
				preparadorSQL.close();

				return posicaoBrada;

			} catch (Exception e) {
				//System.out.println( dateFormat.format(dia)+ " ERRO::procurarBrada::" +e.getMessage());
				return posicaoBrada;
			}
		}
	}
	
	/**
	 * Associa a mensagem a conta e retorna uma CONTA com mensagem
	 * @param telefone
	 * @param mensagem
	 * @return CONTA
	 */
	private Conta contaComMensagem(int telefone, List<Integer> mensagem){
		Conta conta = getConta(telefone, "", "");
		conta.setMensagem(mensagem);
		return conta;
	}
}