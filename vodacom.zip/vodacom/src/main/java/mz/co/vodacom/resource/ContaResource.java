package mz.co.vodacom.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import mz.co.vodacom.dao.ContaDAO;
import mz.co.vodacom.modelo.Bradas;
import mz.co.vodacom.modelo.Conta;
import mz.co.vodacom.modelo.TransferirCredito;

@Path("/contas")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ContaResource {

	ContaDAO contaDAO = new ContaDAO();
	
	/** API para adicionar uma conta **/
	@POST
	public int addConta(Conta conta){
		return contaDAO.addConta(conta);
	}
	
	/** API para apagar uma conta **/
	@DELETE
	@Path("/{contaId}")
	public int deleteConta(@PathParam("contaId") int telefone){
		return contaDAO.deleteConta(telefone);
	}
	
	/** API para recuperar uma conta **/
	@PUT
	@Path("/{contaId}")
	@Consumes(MediaType.TEXT_PLAIN)
	public Conta getConta(@PathParam("contaId") int telefone, String password){
		return contaDAO.getConta(telefone, password, "login");
	}
	
	/** API para recuperar todas contas **/
	@GET
	public List<Conta> getContas(){
		return contaDAO.getContas();
	}
	
	/** API para actualizar uma conta 
	@PUT
	@Path("/{contaId}")
	public int updateConta(@PathParam("contaId") int telefone, Conta conta){
		return contaDAO.updateConta(telefone, conta);
	}
	
	/** API para actualizar a Notificacao de Saldo **/
	@PUT
	@Path("/{contaId}/notif_sal")
	@Consumes(MediaType.TEXT_PLAIN)
	public Conta updateNotificacaoSaldo(@PathParam("contaId") int telefone, String notificacao){
		return contaDAO.updateNotificacaoSaldo(telefone, notificacao);
	}
	
	/** API para actualizar a Transferencia de Credito **/
	@PUT
	@Path("/{contaId}/recar_sal")
	@Consumes(MediaType.TEXT_PLAIN)
	public Conta updateRecarregarSaldo(@PathParam("contaId") int telefone, String codigoRecarga){
		return contaDAO.updateRecarregarSaldo(telefone, codigoRecarga);
	}
	
	/** API para actualizar a Transferencia de Credito **/
	@PUT
	@Path("/{contaId}/transf_cred")
	public Conta updateTransferirSaldo(@PathParam("contaId") int telefone, TransferirCredito transferencia){
		return contaDAO.updateTransferirCredito(telefone, transferencia);
	}
	
	/** API para actualizar o Tarifario**/
	@PUT
	@Path("/{contaId}/tarifario")
	@Consumes(MediaType.TEXT_PLAIN)
	public Conta updateTarifario(@PathParam("contaId") int telefone, String tarifa){
		return contaDAO.updateTarifario(telefone, tarifa);
	}
	
	/** API para adicionar um Brada **/
	@PUT
	@Path("/{contaId}/bradas")
	@Consumes(MediaType.TEXT_PLAIN)
	public Conta addBrada(@PathParam("contaId") int telefone, String brada){
		return contaDAO.addBrada(telefone, brada);
	}

	/** API para apagar um ou varios Bradas **/
	@DELETE
	@Path("/{contaId}/bradas")
	public Conta deleteBrada(@PathParam("contaId") int telefone, Bradas bradas){
		return contaDAO.deleteBrada(telefone, bradas);
	}
	
	@GET
	@Path("/teste")
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.TEXT_PLAIN)
	public String teste(String conteudo){
		return "Deus esta sempre comigo";
	}
}